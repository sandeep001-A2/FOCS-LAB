# Foundation of Cyber Security (FOCS) Lab Experiments

This repository contains the practical lab experiments, implementation code, documentation, and execution screenshots for the **Foundation of Cyber Security (FOCS)** course.

## Repository Structure

```text
Foundation-of-Cyber-Security/
├── Experiment 1/
│   ├── Experiment 1                               # Theory, Google search operators & dorking techniques
│   └── Experiment 1 screenshorts.pdf              # Execution screenshots
├── Experiment 2/
│   ├── Experiment 2                               # Buffer overflow in C, vulnerability demo & mitigations
│   └── Experiment 2 codes screenshorts.pdf        # Code and execution screenshots
├── Experiment 3/
│   ├── Experiment 3                               # Host scanning and reconnaissance with Nmap
│   └── Experiment 3 SS.pdf                        # Scan outputs and execution screenshots
├── Experiment 4/
│   ├── Experiment 4                               # Network packet capture and analysis with Wireshark
│   ├── Experiment 4 Installation of Wireshark     # Wireshark setup instructions
│   └── Experiment 4 Screenshots & Execution .pdf  # Packet analysis screenshots
├── Experiment 5/
│   ├── Experiment 5                               # Brute force and dictionary attacks with Hydra
│   ├── Experiment 5 Kali Linux  and Hydra Installation  # Setup guide for Kali Linux & Hydra
│   └── Experiment 5 Screenshots & Execution .pdf  # Attack execution screenshots
├── Experiment 6/
├── Experiment 7/
├── Experiment 8/
├── Experiment 9/
├── Experiment 10/
├── README.md
└── .gitignore
```

---

## Experiments Overview

| Experiment | Title / Topic | Tools / Technologies |
| :--- | :--- | :--- |
| **Experiment 1** | Information Gathering using Google Search Techniques (Google Dorking) | Google Search Engine |
| **Experiment 2** | Buffer Overflow Vulnerability Demonstration and Mitigation | C Programming, GCC |
| **Experiment 3** | Host Scanning and Information Gathering | Nmap, Ncat, Command Prompt |
| **Experiment 4** | Packet Capturing and Protocol Analysis | Wireshark |
| **Experiment 5** | Password Security: Brute Force & Dictionary Attacks | Kali Linux, Hydra |
| **Experiment 6** | *Experiment 6* | *Pending upload* |
| **Experiment 7** | *Experiment 7* | *Pending upload* |
| **Experiment 8** | *Experiment 8* | *Pending upload* |
| **Experiment 9** | *Experiment 9* | *Pending upload* |
| **Experiment 10** | *Experiment 10* | *Pending upload* |

---

## Author
- **Mirza Younis Hussain** ([@MirzaYounisHussain](https://github.com/MirzaYounisHussain))
